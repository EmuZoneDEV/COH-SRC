#ifndef __AFMODULE_H__
#define __AFMODULE_H__

#include <ft2build.h>
#include FT_MODULE_H


FT_BEGIN_HEADER

  FT_CALLBACK_TABLE
  const FT_Module_Class  autofit_module_class;


FT_END_HEADER

#endif /* __AFMODULE_H__ */
